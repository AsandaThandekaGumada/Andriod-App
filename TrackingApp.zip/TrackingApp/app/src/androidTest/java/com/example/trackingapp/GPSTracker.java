package com.example.trackingapp;

public class GPSTracker {
}
